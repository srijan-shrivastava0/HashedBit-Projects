import React from "react";
import IPLTable from "./IPLTable";

function App() {
  return (
    <div className="App">
      <IPLTable />
    </div>
  );
}

export default App;
