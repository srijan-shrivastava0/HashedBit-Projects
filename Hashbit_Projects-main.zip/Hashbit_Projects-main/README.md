# Hashbit_Projects
these are the assignment given by hashbit 
