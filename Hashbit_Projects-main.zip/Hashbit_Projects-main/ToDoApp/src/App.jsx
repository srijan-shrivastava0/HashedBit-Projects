import React from 'react';
import TodoList from './ToDoApp';

function App() {
  return (
    <div className="App">
      <TodoList />
    </div>
  );
}

export default App;
